# -*- coding: utf-8 -*-
"""
Created on Mon Jun 23 06:10:52 2025

@author: masok
"""

"Data from COCOBOD, GhanaWeb (Cocoa Prices), World Bank(CPI), IMF (Inflation Projections), Bank of Ghana, exhchange-rates.org (USD/GHS rates)"

"Ghanaian Cedi (GHS), U.S. Dollar (USD)"

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.metrics import r2_score, mean_squared_error



# Imports the base dataset with historical nominal cocoa prices (in GHS), 
# historical fx rates, conversion to nominal USD, and historical CPI data for Ghana and USA. 
cocoa = pd.read_csv("C:\\Users\\masok\\OneDrive\\Documents\\NIMSAssignment\\python\\cocoainf.csv")
cocoa.set_index('year', inplace=True)

# Calculates the 'real' (2010) prices in GHS and USD
cocoa['gh_cpi_index'] = cocoa['gh_cpi']/100
cocoa['2010_ghc'] = cocoa['price_ghs']/cocoa['gh_cpi_index']
cocoa[['price_ghs','gh_cpi_index','2010_ghc']]

cocoa['usd_cpi_index'] = cocoa['usd_cpi']/100
cocoa['2010_usd'] = cocoa['nominal_usd']/cocoa['usd_cpi_index']
cocoa[['nominal_usd','usd_cpi_index','2010_usd']]

# Plots nominal vs. 'real' historical prices in GHS
plt.figure(figsize=(12, 6))
sns.lineplot(data=cocoa, x='year', y='price_ghs', label='Nominal GHS', color='green')
sns.lineplot(data=cocoa, x='year', y='2010_ghc', label="'Real' GHS (2010)", color='red')
plt.title("Cocoa Prices Adjusted for Inflation (GHS, tonne)")
plt.xlabel("Year")
plt.ylabel("Price (GHS)")
plt.grid(True)
plt.show()

# Plots nominal vs. 'real' historical prices in USD
plt.figure(figsize=(12, 6))
sns.lineplot(data=cocoa, x='year', y='nominal_usd', label='Nominal USD', color='green')
sns.lineplot(data=cocoa, x='year', y='2010_usd', label="'Real' USD (2010)", color='red')
plt.title("Cocoa Prices Adjusted for Inflation (USD, tonne)")
plt.xlabel("Year")
plt.ylabel("Price (USD)")
plt.grid(True)
plt.show()

df = cocoa

# Copies the year and 'real' price data for Ghana to independent dataset
df_ghs = df.reset_index()[['year','2010_ghc']].rename(columns = {'year':'ds','2010_ghc':'y'})
df_ghs['ds'] = pd.to_datetime(df_ghs['ds'], format='%Y')
df_ghs['year'] = df_ghs['ds'].dt.year

# Scales price data between 0 and 1 for more accurate regression
scaler = MinMaxScaler(feature_range=(0,1))
df_ghs['y_scaled'] = scaler.fit_transform(df_ghs[['y']])

# Sets variables for polynomial regression
x = df_ghs[['year']]
y = df_ghs['y_scaled']

# Creates the polynomial regression model based on a cubic function
model = make_pipeline(PolynomialFeatures(degree=3), LinearRegression())
model.fit(x, y)
 
# Predicts fit based on training data
y_pred = model.predict(x)
r2 = r2_score(y, y_pred)
rmse = np.sqrt(mean_squared_error(y, y_pred))

print("R2: ",r2)
print("RMSE: ",rmse)

# Predicts future 'real' prices in Ghanaian Cedi (GHS) for the years 2025-2030
future_years = pd.DataFrame({'year': np.arange(2025, 2031)})
future_scaled = model.predict(future_years[['year']])
future_prices = scaler.inverse_transform(future_scaled.reshape(-1, 1))

# Adds forecasted 'real' prices to new forecast dataframe
forecast = future_years.copy()
forecast['2010_ghs'] = future_prices
forecast['ds'] = pd.to_datetime(forecast['year'], format='%Y')

# Sets initial cpi to estimate nominal cpi for future years
base_cpi_gh = cocoa.loc[2024, 'gh_cpi']
start_year = forecast.loc[0,'year']

# Finds the future CPIs using World Bank forecasted inflation rates for Ghana
forecast['inflation_gh'] = [0.172, 0.094, 0.08, 0.08, 0.08, 0.08]
forecast['gh_cpi'] = base_cpi_gh * (1 + forecast.loc[0,'inflation_gh'])
for i in range(1, len(forecast)):
    prev_cpi = forecast.loc[i-1, 'gh_cpi']
    infl = forecast.loc[1, 'inflation_gh']
    forecast.loc[i, 'gh_cpi'] = prev_cpi * (1+infl)



# Calculates predicted nominal prices using forecasted CPIs. 
forecast['gh_cpi_index'] = forecast['gh_cpi']/100
forecast['predicted_nominal'] = forecast['2010_ghs'] * forecast['gh_cpi_index']



fairtrade = 31250

# Plots both historical and forecasted 'real' and nominal prices in GHS. 
plt.figure(figsize=(10, 6))
plt.plot(df_ghs['ds'], cocoa['2010_ghc'], label=" 'Real' Historical Prices", marker='o')
plt.plot(df_ghs['ds'], cocoa['price_ghs'], label=' Nominal Historical Prices', marker='o')
plt.plot(forecast['ds'], forecast['2010_ghs'], label="'Real'Forecast (2025–2030)", linestyle='--', marker='x')
plt.plot(forecast['ds'], forecast['predicted_nominal'], label="Nominal Forecast (2025–2030)", linestyle='--', marker='x')
plt.title('Cocoa Price Forecast (Inflation-adjusted, GHS, tonne)')
plt.xlabel('Year')
plt.ylabel('Price (GHS, 2010 terms)')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()


# Lists the forecasted inflation rates of the US and the 2025 GHS/USD exchange rate (stable at 10.30 as of June 2025)
forecast['inflation_us'] = [0.03, 0.025, 0.021, 0.022, 0.022, 0.022]
initial_fx = 10.30

# Creates list which will contain the forecasted fx rates to compare from nominal USD to GHS
fx_rates = [initial_fx]


for i in range (1, len(forecast)):
    gh_inf = forecast.loc[i, 'inflation_gh']
    us_inf = forecast.loc[i, 'inflation_us']
    prev_fx = fx_rates[-1]
    next_fx = prev_fx * ((1 + gh_inf) / (1 + us_inf))
    fx_rates.append(next_fx)

# Adds forecasted fx rates to forecast data frame
forecast['fx'] = fx_rates

# Adds nominal USD figures to forecast dataframe 
forecast['nominal_usd'] = forecast['predicted_nominal']/forecast['fx']

# Finds base CPI which will be used to estimate future U.S. CPIs using forecasted U.S. inflation
base_cpi_us = cocoa.loc[2024, 'usd_cpi']
forecast['usd_cpi'] = base_cpi_us * (1 + forecast.loc[0,'inflation_us'])

for i in range(1, len(forecast)):
    prev_cpi = forecast.loc[i-1, 'usd_cpi']
    infl = forecast.loc[1, 'inflation_us']
    forecast.loc[i, 'usd_cpi'] = prev_cpi * (1+infl)
    
# Calculates 'real' USD figures using forecasted CPIs.   
forecast['us_cpi_index'] = forecast['usd_cpi']/100
forecast['2010_usd'] = forecast['nominal_usd']/forecast['us_cpi_index']




# Plots both historical and forecasted 'real' and nominal prices in USD.
plt.figure(figsize=(10, 6))
plt.plot(df_ghs['ds'], cocoa['2010_usd'], label=' "Real" Historical Prices', marker='o')
plt.plot(df_ghs['ds'], cocoa['nominal_usd'], label='Nominal Historical Prices', marker='o')
plt.plot(forecast['ds'], forecast['2010_usd'], label=' "Real" Forecast (2025–2030)', linestyle='--', marker='x')
plt.plot(forecast['ds'], forecast['nominal_usd'], label=' Nominal Forecast (2025–2030)', linestyle='--', marker='x')
plt.title('Cocoa Price Forecast (Inflation-adjusted, USD, tonne)')
plt.xlabel('Year')
plt.ylabel('Price (USD, 2010 terms)')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()


