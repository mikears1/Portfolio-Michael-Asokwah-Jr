# -*- coding: utf-8 -*-
"""
Created on Fri Jun 20 06:29:27 2025

@author: masok
"""

"Data from COCOBOD (Cocoa Prices), World Bank(CPI), Bank of Ghana, exhchange-rates.org (USD/GHS rates)"


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import MinMaxScaler



cocoa = pd.read_csv("C:\\Users\\masok\\OneDrive\\Documents\\NIMSAssignment\\python\\cocoafive.csv")

cocoa.set_index('year', inplace=True)

cocoa['gh_cpi_index'] = cocoa['gh_cpi']/100
cocoa['2010_ghc'] = cocoa['price_ghs_64kg']/cocoa['gh_cpi_index']
cocoa[['price_ghs_64kg','gh_cpi_index','2010_ghc']]

cocoa['usd_cpi_index'] = cocoa['usd_cpi']/100
cocoa['2010_usd'] = cocoa['nominal_usd']/cocoa['usd_cpi_index']
cocoa[['nominal_usd','usd_cpi_index','2010_usd']]

plt.figure(figsize=(12, 6))
sns.lineplot(data=cocoa, x='year', y='price_ghs_64kg', label='Nominal GHS', color='green')
sns.lineplot(data=cocoa, x='year', y='2010_ghc', label="'Real' GHS (2010)", color='red')
plt.title("Cocoa Prices Adjusted for Inflation (GHS)")
plt.xlabel("Year")
plt.ylabel("Price (GHS)")
plt.grid(True)
plt.show()

plt.figure(figsize=(12, 6))
sns.lineplot(data=cocoa, x='year', y='nominal_usd', label='Nominal USD', color='green')
sns.lineplot(data=cocoa, x='year', y='2010_usd', label="'Real' USD (2010)", color='red')
plt.title("Cocoa Prices Adjusted for Inflation (USD)")
plt.xlabel("Year")
plt.ylabel("Price (USD)")
plt.grid(True)
plt.show()

df = cocoa

df_ghs = df.reset_index()[['year','2010_ghc']].rename(columns = {'year':'ds','2010_ghc':'y'})
df_ghs['ds'] = pd.to_datetime(df_ghs['ds'], format='%Y-%m')
df_ghs['year'] = df_ghs['ds'].dt.year

scaler = MinMaxScaler(feature_range=(0,1))
df_ghs['y_scaled'] = scaler.fit_transform(df_ghs[['y']])


x = df_ghs[['year']]
y = df_ghs['y_scaled']

model = LinearRegression()
model.fit(x, y)

future_years = pd.DataFrame({'year': np.arange(2025, 2031)})
future_scaled = model.predict(future_years[['year']])
future_prices = scaler.inverse_transform(future_scaled.reshape(-1, 1))


# Combine into forecast DataFrame
forecast = future_years.copy()
forecast['Predicted_Price'] = future_prices
forecast['ds'] = pd.to_datetime(forecast['year'], format='%Y')

print(forecast)

plt.figure(figsize=(10, 6))
plt.plot(df_ghs['ds'], df_ghs['y'], label='Historical Prices', marker='o')
plt.plot(forecast['ds'], forecast['Predicted_Price'], label='Forecast (2025–2030)', linestyle='--', marker='x')
plt.title('Cocoa Price Forecast (Inflation-adjusted, GHS)')
plt.xlabel('Year')
plt.ylabel('Price (GHS, 2010 terms)')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()


df_usd = df.reset_index()[['year','2010_usd']].rename(columns = {'year':'ds','2010_usd':'y'})
df_usd['ds'] = pd.to_datetime(df_usd['ds'], format='%Y-%m')
df_usd['year'] = df_ghs['ds'].dt.year

scaler = MinMaxScaler(feature_range=(0,1))
df_usd['y_scaled'] = scaler.fit_transform(df_usd[['y']])

x = df_usd[['year']]
y = df_usd['y_scaled']

model = LinearRegression()
model.fit(x, y)

future_years = pd.DataFrame({'year': np.arange(2025, 2031)})
future_scaled = model.predict(future_years[['year']])
future_prices = scaler.inverse_transform(future_scaled.reshape(-1, 1))

# Combine into forecast DataFrame
forecast = future_years.copy()
forecast['Predicted_Price'] = future_prices
forecast['ds'] = pd.to_datetime(forecast['year'], format='%Y')

print(forecast)

plt.figure(figsize=(10, 6))
plt.plot(df_usd['ds'], df_usd['y'], label='Historical Prices', marker='o')
plt.plot(forecast['ds'], forecast['Predicted_Price'], label='Forecast (2025–2030)', linestyle='--', marker='x')
plt.title('Cocoa Price Forecast (Inflation-adjusted, USD)')
plt.xlabel('Year')
plt.ylabel('Price (GHS, 2010 terms)')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

