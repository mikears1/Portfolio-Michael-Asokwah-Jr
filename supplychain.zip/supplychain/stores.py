# -*- coding: utf-8 -*-
"""
Created on Tue Sep  9 15:35:47 2025

@author: masok
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from geopy.geocoders import Nominatim
from shapely.geometry import Point
import geopandas as gpd
from geopy.exc import GeocoderTimedOut, GeocoderUnavailable
import time
from shapely.geometry import LineString
import contextily as ctx 




# This code maps the H-E-B store locations in Bryan-College Station. 

# 1. Read CSV
df = pd.read_csv("C:\\Users\\masok\\Downloads\\store-list-bcs.csv")

# 2. Check for invalid lat/lon
df = df.dropna(subset=['longitude', 'latitude'])

# 3. Build Point geometry
df['geometry'] = df.apply(lambda row: Point(row['longitude'], row['latitude']), axis=1)

# 4. Create GeoDataFrame with WGS84
store_gdf = gpd.GeoDataFrame(df, geometry='geometry', crs='EPSG:4326')

# 5. Reproject to Web Mercator
store_gdf_web = store_gdf.to_crs(epsg=3857)

# 6. Plot
fig, ax = plt.subplots(figsize=(10, 10))

# Plot store points (Web Mercator)
store_gdf_web.plot(
    ax=ax,
    color='red',
    markersize=20,
    label='Store'
)


# Adds labels to store points
for idx, row in store_gdf_web.iterrows():
    x, y = row.geometry.x, row.geometry.y
    label = row['Store Name']  

    dx, dy = -2000, 300  

    ax.annotate(
        label,
        xy=(x, y),
        xytext=(x + dx, y + dy),
        textcoords="data",
        fontsize=12,
        fontname='Segoe UI',
        ha='left',
        color='red',
        clip_on=True  
    )


# Sets limits for map size
ax.set_xlim(store_gdf_web.geometry.x.min() - 5000, store_gdf_web.geometry.x.max() + 5000)
ax.set_ylim(store_gdf_web.geometry.y.min() - 5000, store_gdf_web.geometry.y.max() + 5000)
        
ctx.add_basemap(ax, source=ctx.providers.CartoDB.Positron)

# Final styling
ax.set_title("H-E-B Store Locations: Bryan-College Station Market", fontsize=20, fontname='Segoe UI')
ax.axis('off')
plt.tight_layout()
plt.show()


